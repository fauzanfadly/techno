<template>
    <div>
        <dashboard-layout>
            <v-container>
                <v-row>
                    <v-col md="12">
                        <v-form
                            v-model="valid"
                            lazy-validation
                            @submit.prevent="submitForm"
                        >
                            <v-card>
                                <v-container>
                                    <v-row dense>
                                        <v-col md="auto" align-self="center">
                                            <v-btn
                                                icon
                                                variant="text"
                                                density="compact"
                                                @click="() => $router.back()"
                                            >
                                                <v-icon>mdi-chevron-left</v-icon>
                                            </v-btn>
                                        </v-col>
                                        <v-col class="text-h5">
                                            <p v-if="paramId">Product Series</p>
                                            <p v-else>Create Product Series</p>
                                        </v-col>
                                        <v-divider class="mb-5"></v-divider>
                                        <v-col cols="12">
                                            <v-text-field
                                                label="Name"
                                                v-model="form.name"
                                                :rules="[v => !!v || 'Name is required']"
                                            />
                                        </v-col>
                                        <v-col cols="12">
                                            <v-autocomplete
                                                ref="manufactureTypeField"
                                                label="Manufacture Type"
                                                v-model="form.mt_manufacture_type_id"
                                                :items="optionValues.manufactureTypes"
                                                :rules="[v => !!v || 'Manufacture type is required']"
                                                return-object
                                                @update:modelValue="fetchChilds"
                                            />
                                        </v-col>
                                        <v-col cols="12">
                                            <v-autocomplete
                                                ref="vendorField"
                                                label="Vendor"
                                                v-model="form.mt_vendor_id"
                                                :items="optionValues.vendors"
                                                :rules="[v => !!v || 'Vendor is required']"
                                                :disabled="!form.mt_manufacture_type_id"
                                                return-object
                                                @update:modelValue="fetchChilds"
                                            />
                                        </v-col>
                                        <v-col cols="12">
                                            <v-autocomplete
                                                label="Category"
                                                v-model="form.mt_product_category_id"
                                                :items="optionValues.productCategories"
                                                :rules="[v => !!v || 'Category is required']"
                                                :disabled="!form.mt_vendor_id"
                                            />
                                        </v-col>
                                        <v-col cols="auto">
                                            <v-img
                                                v-if="image.path"
                                                width="200"
                                                height="200"
                                                cover
                                                :src="getStorageFile(image.path)"
                                                class="rounded-lg border-sm"
                                            >
                                                <v-btn
                                                    class="rounded-0 position-absolute bottom-0 right-0 pa-1 w-fit"
                                                    varian="outlined"
                                                    density="compact"
                                                    @click="() => openImageFullscreen(image.path)"
                                                ><v-icon>mdi-fullscreen</v-icon></v-btn>
                                            </v-img>
                                            <v-icon
                                                v-else
                                                size="200"
                                                color="grey"
                                            >
                                                mdi-image-off-outline
                                            </v-icon>
                                        </v-col>
                                        <v-col align-self="end">
                                            <v-text-field
                                                label="Image File"
                                                v-model="image.name"
                                                @click="() => openSelectImageDialog()"
                                                @focus="() => openSelectImageDialog()"
                                            />
                                            <SelectFileImageDialog
                                                @click:image="onSelectImage"
                                            ></SelectFileImageDialog>
                                        </v-col>
                                        <v-col cols="12">
                                            <v-textarea
                                                label="Description"
                                                v-model="form.description"
                                                variant="outlined"
                                                density="compact"
                                            />
                                        </v-col>
                                        <v-col cols="12">
                                            <v-btn
                                                type="submit"
                                                color="primary"
                                            >
                                                Submit
                                            </v-btn>
                                        </v-col>
                                    </v-row>
                                </v-container>
                            </v-card>
                        </v-form>
                    </v-col>
                </v-row>
            </v-container>
        </dashboard-layout>
    </div>
</template>


<script setup>
import DashboardLayout from '@/layouts/DashboardLayout.vue';
import { onMounted, ref, useTemplateRef } from 'vue';
import { useRouter } from 'vue-router';
import { openSnackbar } from "../../../utils/snackbar";
import { useUserStore } from '../../../store/user';
import { Request } from '../../../utils/request';
import { getStorageFile } from '../../../utils/storage';
import { openImageFullscreen } from '../../../utils/image_full_screen_dialog';
import { openSelectImageDialog } from '../../../utils/select_file_image_dialog';
import SelectFileImageDialog from '../../../components/dialogs/SelectFileImageDialog.vue';
import { collect } from '../../../utils/collection';
import { fetchServices } from '../../../utils/fetch_services';


const router = useRouter();
const userStore = useUserStore();
const manufactureTypeField = useTemplateRef('manufactureTypeField');
const vendorField = useTemplateRef('vendorField');
const valid = ref(false);
const form = ref({
    name: '',
    description: '',
    image_id: null,
    mt_manufacture_type_id: null,
    mt_vendor_id: null,
    mt_product_category_id: null,
});
const optionValues = ref({
    manufactureTypes: [],
    vendors: [],
    productCategories: [],
});
const paramId = ref(null);
const image = ref({
    name: null,
    path: null,
});


onMounted(async () => {
    await fetchManufactureTypes();

    paramId.value = router.currentRoute.value.params.id || null;
    if (paramId.value) {
        await fetchDetail(paramId.value);
    }
});


const fetchManufactureTypes = async () => {
    optionValues.value.manufactureTypes = await fetchServices.listOfValue({
        url: '/api/manufacture-type',
        titleKey: 'name',
        valueKey: 'id',
    });
}

const fetchChilds = (value) => {
    let valueKey = "";
    let formIdKey = "";
    let optionKey = "";

    if (value.data.mt_vendor) {
        valueKey = "mt_vendor";
        formIdKey = "mt_vendor_id";
        optionKey = "vendors";
    } else if (value.data.mt_product_category) {
        valueKey = "mt_product_category";
        formIdKey = "mt_product_category_id";
        optionKey = "productCategories";
    }

    const _items = collect(value.data[valueKey]);
    optionValues.value[optionKey] = fetchServices.generateListOfValue({
        items: _items.get(),
        valueKey: 'id',
        titleKey: 'name',
    });
    form.value[formIdKey] = !!(_items.find('id', form.value[formIdKey]))
        ? form.value[formIdKey]
        : null;
}

const fetchDetail = async (id) => {
    await Request.get({
        url: `/api/product/series/detail/${id}`,
        errorMessage: `Failed when fetching product series "${id}"`,
        useLoading: true,
    })
        .then(({ data }) => {
            const _productCategory = data.data.mt_product_category;
            const _vendorId = _productCategory.mt_vendor.id;
            const _manufactureTypeId = _productCategory.mt_vendor.mt_manufacture_type.id;
            const _image = data.data.image;

            form.value.name = data.data.name;
            form.value.description = data.data.description;
            form.value.mt_manufacture_type_id = _manufactureTypeId;
            form.value.mt_vendor_id = _vendorId;
            form.value.mt_product_category_id = _productCategory.id;

            const _manufactureType = collect(optionValues.value.manufactureTypes).find('value', _manufactureTypeId);
            manufactureTypeField.value.$emit('update:modelValue', _manufactureType);

            const _vendor = collect(optionValues.value.vendors).find('value', _vendorId);
            vendorField.value.$emit('update:modelValue', _vendor);

            onSelectImage(_image);
        });
}

const onSelectImage = (value) => {
    form.value.image_id = value.id;
    image.value.name = value.name;
    image.value.path = value.image_path;
}

const submitForm = async () => {
    if (!valid.value) {
        return;
    }

    let url = "/api/product/series/create";
    let errorMessage = "Failed when creating product series";
    if (paramId.value) {
        url = `/api/product/series/update/${paramId.value}`;
        errorMessage = `Failed when updating product series "${paramId.value}"`;
    }

    await Request.post({
        url,
        data: form.value,
        errorMessage,
        useLoading: true,
    })
        .then(({ data }) => {
            router.back();
            setTimeout(() => {
                openSnackbar({
                    message: data.message || "Product series created successfully",
                    status: "success",
                });
            }, 10);
        });
};
</script>
